// Background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("WiFi Portal Auto Login extension installed");
});

// Listen for tab updates to detect when we're on the login page
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    // Check if the page contains the login form
    chrome.scripting
      .executeScript({
        target: { tabId },
        function: () => {
          const hasLoginForm =
            !!document.querySelector('input[type="text"]') &&
            !!document.querySelector('input[type="password"]') &&
            !!document.querySelector(
              'input[type="submit"], button[type="submit"], button'
            );
          return hasLoginForm;
        },
      })
      .then(([result]) => {
        if (result.result) {
          // Show the extension icon in an active state
          chrome.action.setIcon({
            tabId,
            path: {
              16: "Wifi_icon.png",
              48: "Wifi_icon.png",
              128: "Wifi_icon.png",
            },
          });

          // Inject the content script if not already injected
          chrome.scripting
            .executeScript({
              target: { tabId },
              files: ["content.js"],
            })
            .catch((error) => {
              // console.error("Error injecting content script:", error);
            });
        }
      })
      .catch((error) => {
        console.error("Error checking login form:", error);
      });
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "loginFormFound" && sender.tab) {
    console.log("Login form found on page:", sender.tab.url);
    console.log("Form details:", request.details);

    // Update icon when login form is found
    chrome.action.setIcon({
      tabId: sender.tab.id,
      path: {
        16: "Wifi_icon.png",
        48: "Wifi_icon.png",
        128: "Wifi_icon.png",
      },
    });
  }
});
