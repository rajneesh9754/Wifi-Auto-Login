// This script runs in the context of the webpage
console.log('WiFi Portal Auto Login extension loaded');

// Function to check if we're on a login page with more flexible selectors
function isLoginPage() {
  const usernameField = document.querySelector('input[type="text"]') || 
                       document.querySelector('input[name="username"]') ||
                       document.querySelector('input[name="user"]');

  const passwordField = document.querySelector('input[type="password"]');
  const checkbox = document.querySelector('input[type="checkbox"]');
  const loginButton = document.querySelector('input[type="submit"]') || 
                     document.querySelector('button[type="submit"]') || 
                     document.querySelector('button:contains("Login")') ||
                     document.querySelector('button');

  return {
    isLoginForm: !!(usernameField && passwordField && checkbox && loginButton),
    elements: {
      hasUsername: !!usernameField,
      hasPassword: !!passwordField,
      hasCheckbox: !!checkbox,
      hasLoginButton: !!loginButton
    }
  };
}

// Function to find all possible login forms
function findLoginForms() {
  const forms = Array.from(document.getElementsByTagName('form'));
  return forms.filter(form => {
    const inputs = form.getElementsByTagName('input');
    const hasText = Array.from(inputs).some(input => 
      input.type === 'text' || 
      input.name === 'username' || 
      input.name === 'user'
    );
    const hasPassword = Array.from(inputs).some(input => input.type === 'password');
    const hasCheckbox = Array.from(inputs).some(input => input.type === 'checkbox');
    return hasText && hasPassword && hasCheckbox;
  });
}

// Function to perform auto login
async function performAutoLogin() {
  try {
    // Get saved credentials
    const result = await chrome.storage.local.get(['username', 'password', 'saveCredentials']);
    if (!result.saveCredentials || !result.username || !result.password) {
      console.log('No saved credentials found');
      return;
    }

    // Find form elements
    const usernameField = document.querySelector('input[type="text"]') || 
                         document.querySelector('input[name="username"]') ||
                         document.querySelector('input[name="user"]');

    const passwordField = document.querySelector('input[type="password"]');
    const agreeCheckbox = document.querySelector('input[type="checkbox"]');
    const loginButton = document.querySelector('input[type="submit"]') || 
                       document.querySelector('button[type="submit"]') || 
                       document.querySelector('button:contains("Login")') ||
                       document.querySelector('button');

    if (!usernameField || !passwordField || !agreeCheckbox || !loginButton) {
      console.log('Login form elements not found');
      return;
    }

    // Create events
    const inputEvent = new Event('input', { bubbles: true });
    const changeEvent = new Event('change', { bubbles: true });
    const clickEvent = new MouseEvent('click', {
      bubbles: true,
      cancelable: true,
      view: window
    });

    // Fill in credentials
    usernameField.value = result.username;
    usernameField.dispatchEvent(inputEvent);
    usernameField.dispatchEvent(changeEvent);

    passwordField.value = result.password;
    passwordField.dispatchEvent(inputEvent);
    passwordField.dispatchEvent(changeEvent);

    // Force the checkbox to be checked and trigger events
    setTimeout(() => {
      agreeCheckbox.checked = true;
      agreeCheckbox.dispatchEvent(changeEvent);
      agreeCheckbox.dispatchEvent(clickEvent);

      // Try to find the form
      const form = loginButton.closest('form');

      // Add a delay before submitting
      setTimeout(() => {
        // Try multiple submission methods
        if (form) {
          // Create form submit event
          const submitEvent = new Event('submit', {
            bubbles: true,
            cancelable: true
          });
          form.dispatchEvent(submitEvent);
        }

        // Also try clicking the button
        loginButton.focus();
        loginButton.click();
        loginButton.dispatchEvent(clickEvent);

      }, 1000);
    }, 500);
  } catch (error) {
    console.error('Auto-login error:', error);
  }
}

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLoginForm') {
    const loginStatus = isLoginPage();
    const forms = findLoginForms();
    sendResponse({ 
      hasLoginForm: loginStatus.isLoginForm, 
      formCount: forms.length,
      details: loginStatus.elements
    });
  }
});

// Observe DOM changes to detect dynamically loaded forms
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    if (mutation.type === 'childList') {
      const loginStatus = isLoginPage();
      if (loginStatus.isLoginForm) {
        chrome.runtime.sendMessage({ 
          action: 'loginFormFound',
          details: loginStatus.elements
        });
        // Attempt auto-login when form is found
        performAutoLogin();
        break;
      }
    }
  }
});

// Start observing with configuration
observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['style', 'class', 'disabled', 'hidden'] // Watch for visibility and state changes
});

// Also try auto-login when the page loads
if (isLoginPage().isLoginForm) {
  performAutoLogin();
}