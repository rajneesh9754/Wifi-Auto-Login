document.addEventListener('DOMContentLoaded', () => {
  const loginButton = document.getElementById('loginButton');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const saveCredentialsCheckbox = document.getElementById('saveCredentials');
  const statusDiv = document.getElementById('status');

  // Load saved credentials
  chrome.storage.local.get(['username', 'password', 'saveCredentials'], (result) => {
    if (result.saveCredentials) {
      usernameInput.value = result.username || '';
      passwordInput.value = result.password || '';
      saveCredentialsCheckbox.checked = true;
    }
  });

  loginButton.addEventListener('click', async () => {
    const username = usernameInput.value;
    const password = passwordInput.value;

    if (!username || !password) {
      statusDiv.textContent = 'Please enter both username and password';
      statusDiv.className = 'status error';
      return;
    }

    // Save credentials if checkbox is checked
    if (saveCredentialsCheckbox.checked) {
      chrome.storage.local.set({
        username,
        password,
        saveCredentials: true
      });
    } else {
      chrome.storage.local.remove(['username', 'password', 'saveCredentials']);
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      statusDiv.textContent = 'Attempting to login...';
      statusDiv.className = 'status';

      // First, verify if we can find the form elements
      const checkResult = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: checkFormElements
      });

      if (checkResult[0].result.error) {
        throw new Error(checkResult[0].result.error);
      }

      // Proceed with login if form elements are found
      const loginResult = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: performLogin,
        args: [username, password]
      });

      if (loginResult[0].result.success) {
        statusDiv.textContent = 'Login process completed!';
        statusDiv.className = 'status success';
      } else {
        throw new Error(loginResult[0].result.error || 'Login process failed');
      }
    } catch (error) {
      statusDiv.textContent = 'Login failed: ' + error.message;
      statusDiv.className = 'status error';
      console.error('Login error:', error);
    }
  });
});

// Function to check if all form elements are present
function checkFormElements() {
  try {
    const elements = {
      username: document.querySelector('input[type="text"]') || document.querySelector('input[name="username"]'),
      password: document.querySelector('input[type="password"]'),
      checkbox: document.querySelector('input[type="checkbox"]'),
      submit: document.querySelector('input[type="submit"], button[type="submit"], button')
    };

    const missing = Object.entries(elements)
      .filter(([, element]) => !element)
      .map(([name]) => name);

    if (missing.length > 0) {
      return {
        error: `Missing form elements: ${missing.join(', ')}`
      };
    }

    return { success: true, elements: Object.keys(elements) };
  } catch (e) {
    return { error: e.message };
  }
}

// Function to perform the login
function performLogin(username, password) {
  return new Promise((resolve) => {
    try {
      // Find form elements with multiple possible selectors
      const usernameField = document.querySelector('input[type="text"]') || 
                           document.querySelector('input[name="username"]') ||
                           document.querySelector('input[name="user"]');

      const passwordField = document.querySelector('input[type="password"]');
      const agreeCheckbox = document.querySelector('input[type="checkbox"]');
      const loginButton = document.querySelector('input[type="submit"]') || 
                         document.querySelector('button[type="submit"]') || 
                         document.querySelector('button:contains("Login")') ||
                         document.querySelector('button');

      if (!usernameField || !passwordField || !agreeCheckbox || !loginButton) {
        resolve({
          success: false,
          error: 'Login form elements not found',
          details: {
            foundUsername: !!usernameField,
            foundPassword: !!passwordField,
            foundCheckbox: !!agreeCheckbox,
            foundButton: !!loginButton
          }
        });
        return;
      }

      // Create events
      const inputEvent = new Event('input', { bubbles: true });
      const changeEvent = new Event('change', { bubbles: true });
      const clickEvent = new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        view: window
      });

      // Fill in credentials
      usernameField.value = username;
      usernameField.dispatchEvent(inputEvent);
      usernameField.dispatchEvent(changeEvent);

      passwordField.value = password;
      passwordField.dispatchEvent(inputEvent);
      passwordField.dispatchEvent(changeEvent);

      // Force the checkbox to be checked and trigger events
      setTimeout(() => {
        try {
          agreeCheckbox.checked = true;
          agreeCheckbox.dispatchEvent(changeEvent);
          agreeCheckbox.dispatchEvent(clickEvent);

          // Try to find the form
          const form = loginButton.closest('form');

          // Add a delay before submitting
          setTimeout(() => {
            try {
              // Try multiple submission methods
              if (form) {
                // Create form submit event
                const submitEvent = new Event('submit', {
                  bubbles: true,
                  cancelable: true
                });
                form.dispatchEvent(submitEvent);
              }

              // Also try clicking the button
              loginButton.focus();
              loginButton.click();
              loginButton.dispatchEvent(clickEvent);

              resolve({
                success: true,
                message: 'Login actions completed'
              });
            } catch (e) {
              resolve({
                success: false,
                error: 'Error during form submission: ' + e.message
              });
            }
          }, 1000);
        } catch (e) {
          resolve({
            success: false,
            error: 'Error during checkbox handling: ' + e.message
          });
        }
      }, 500);
    } catch (e) {
      resolve({
        success: false,
        error: 'Error during login process: ' + e.message
      });
    }
  });
}